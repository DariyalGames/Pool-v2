#pragma strict

var menucam:GameObject;


function OnMouseDown(){
	
	menucam.SendMessage ("Credits");
}

function Update () {
}