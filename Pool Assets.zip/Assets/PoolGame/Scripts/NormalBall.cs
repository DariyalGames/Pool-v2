﻿using UnityEngine;
using System.Collections;

public class NormalBall : MonoBehaviour 
{
	public int ballID;
	public BallTypes ballType;
	public AudioClip impact;
	public AudioClip pocket;

	// Update is called once per frame
	void Update () 
	{}

	void OnCollisionEnter (Collision other)
	{
		float velocity = Mathf.Max (rigidbody.velocity.x, rigidbody.velocity.z);
		if(other.gameObject.tag == "ball")
		{
			audio.PlayOneShot (impact, velocity * 0.01f);
		}
	}

	void OnTriggerEnter (Collider other)
	{
		if(other.gameObject.name == "abyss")
		{
			audio.PlayOneShot (pocket);
			GameObject.Find (gameObject.name + "_icon").animation.Play ();
			Destroy (gameObject);
			Debug.Log ("[NormalBall]: Raising event pocketed.");
			EventManager.instance.Raise (new BallPocketEvent(ballID, ballType));
		}

		rigidbody.AddForce (new Vector3(0.0f, -100.0f, 0.0f));
	}
}
