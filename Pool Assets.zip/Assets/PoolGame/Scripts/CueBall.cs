﻿using UnityEngine;
using System.Collections;

public class CueBall : MonoBehaviour 
{
	public Transform whiteReset;

	public AudioClip pocket;
	public AudioClip impact;
	public AudioClip cuehit;
	public Camera topCamera;

	public GameObject cue;

	public GUITexture guibar;

	public Transform imaginaryCursor;

	private LineRenderer lineRenderer;

	private float mouseDistance = 0.0f;
	private float cuestr = 0.0f;

	private bool shotTaken = false;

	private Vector3 lastMousePosition;

	// Use this for initialization
	void Start () 
	{
		EventManager.instance.AddListener<StateChanged> (OnStateChanged);
		//EventManager.instance.AddListener<ShotTaken> (OnShotTaken);
		lineRenderer = GetComponent<LineRenderer> ();
		lineRenderer.enabled = false;
		whiteReset.renderer.enabled = false;

		Reset ();
	}

#region Updates
	// FixedUpdate is called when physics is updated.
	void FixedUpdate ()
	{
		switch(GameManager.Instance.CurrentState)
		{
		case GameStates.Shooting:
			if (shotTaken)
			{			
				lineRenderer.enabled = false;
				cue.renderer.enabled = false;
				cue.transform.localPosition = new Vector3(0.0f, 0.1f, -0.4f);
				
				rigidbody.AddForce(1.2f * cuestr * transform.forward);
				//print("shooting");
				
				cuestr = 0;
				audio.PlayOneShot(cuehit);
				guibar.pixelInset = new Rect (-65f,-29f,69f,32f);
				mouseDistance = 0;
				shotTaken = false;
				cue.renderer.enabled = false;
				EventManager.instance.Raise (new ShotTaken());
			}
			break;
		case GameStates.BallMove:
			if ((rigidbody.IsSleeping ()) && (rigidbody.velocity.magnitude == 0))
			{			
				rigidbody.velocity = new Vector3(0.0f, 0.0f, 0.0f);
				cue.renderer.enabled = true;
				
				EventManager.instance.Raise (new BallStopped());
			}
			break;
		}
	}

	// Update is called once per frame
	void Update () 
	{
		switch(GameManager.Instance.CurrentState)
		{
		case GameStates.PlayerTurn:
			if (Input.GetButtonDown("Fire1"))
			{
				lastMousePosition = Input.mousePosition;
				Debug.Log ("[CueBall]: event raise shot power");
				EventManager.instance.Raise (new PowerSelect());
			}
			else 
			{
				Ray ray = topCamera.ScreenPointToRay (Input.mousePosition);
				RaycastHit hit;
				if(Physics.Raycast (ray, out hit, 100.0f))
				{
					imaginaryCursor.position = new Vector3(hit.point.x, transform.position.y, hit.point.z);
				}
				transform.LookAt (imaginaryCursor);
				
				RaycastHit rayhit;
				Physics.Raycast (transform.position, transform.forward, out rayhit);
				lineRenderer.enabled = true;
				lineRenderer.SetPosition(0, gameObject.transform.position);
				lineRenderer.SetPosition(1, rayhit.point);
			}
			break;
		case GameStates.Shooting:
			if (Input.GetButtonUp("Fire1") && !shotTaken)
			{
				shotTaken = true;
			}
			else 
			{
				Vector3 currentMousePosition;
				float delta;
				float lastMouseDistance;
				
				currentMousePosition = new Vector3(Input.mousePosition.x, 0.0f, Input.mousePosition.y);
				lastMouseDistance = mouseDistance;
				
				delta = Vector3.Dot((currentMousePosition - lastMousePosition), transform.forward.normalized);
				mouseDistance += delta;
				mouseDistance = Mathf.Clamp(mouseDistance, -75.0f, 0.0f);
				
				delta = mouseDistance - lastMouseDistance;
				
				cuestr = -mouseDistance * 10.0f;
				guibar.pixelInset = new Rect (-64f, -29f,69f + cuestr / 8f, 32f);
				
				cue.transform.Translate(new Vector3((delta * 0.05f) , 0f, 0f), Space.Self);
				
				lastMousePosition = currentMousePosition;
				//print(mouseDistance);
			}
			break;
		case GameStates.BallMove:
			if (cue.renderer.enabled)
			{
				Debug.Log ("[CueBall]: cue is rendering");
				cue.renderer.enabled = false;
				//cuehelp.renderer.enabled = false;
			}
			break;
		}
	}
#endregion

#region Private Methods
	private void Reset ()
	{
		cue.renderer.enabled = false;

		rigidbody.velocity = new Vector3(0.0f, 0.0f, 0.0f);
		rigidbody.angularVelocity = new Vector3(0.0f, 0.0f, 0.0f);
		transform.position = new Vector3(-7.9f, 4.5f, -9.2f);

		EventManager.instance.Raise (new InGameStart());
	}

	private IEnumerator Reposition ()
	{
		Debug.Log ("[CueBall]: method (Reposition) -start-");
		rigidbody.angularVelocity = new Vector3(0f, 0f, 0f);
		whiteReset.renderer.enabled = true;
		cue.renderer.enabled = false;

		while (Input.GetButtonDown("Fire1") == false)
		{
			//whiteReset.position += new Vector3(Input.GetAxis("Mouse X"), 0f, Input.GetAxis("Mouse Y"));
			whiteReset.position = new Vector3(Mathf.Clamp(Input.GetAxis("Mouse X"), -11.6f, 17f), whiteReset.position.y, Mathf.Clamp(Input.GetAxis("Mouse Y"), -16.2f, -2.4f));			                      
			transform.position = whiteReset.position;
		}

		rigidbody.velocity = new Vector3(0f, 0f, 0f);
		rigidbody.angularVelocity = new Vector3(0f, 0f, 0f);

		whiteReset.renderer.enabled = false;

		yield return new WaitForSeconds(1.0f);

		cue.renderer.enabled = true;

		EventManager.instance.Raise (new RepositionDone());
	}
#endregion

#region Event Listeners

	private void OnCollisionEnter(Collision other)
	{
		float velocity = Mathf.Max (rigidbody.velocity.x, rigidbody.velocity.z);
		if(other.gameObject.tag == "ball")
		{
			audio.PlayOneShot (impact, velocity * 0.01f);
		}
	}

	private void OnTriggerEnter(Collider other)
	{
		Debug.Log ("[CueBall]: event (OnTriggerEnter)");
		if (other.gameObject.name == "abyss" || other.gameObject.name == "room")
		{
			audio.PlayOneShot (pocket);
			EventManager.instance.Raise (new WhiteReposition());
			StartCoroutine(Reposition ());
		}
	}

	private void OnStateChanged (StateChanged e)
	{
		Debug.Log ("[CueBall]: event stat changed");
		switch(GameManager.Instance.CurrentState)
		{
		case GameStates.TurnStart:
			cue.renderer.enabled = true;
			lineRenderer.enabled = true;
			EventManager.instance.Raise (new TurnReady());
			break;
		case GameStates.BallMove:
			cue.renderer.enabled = false;
			lineRenderer.enabled = false;
			break;
		}
	}
#endregion
}
